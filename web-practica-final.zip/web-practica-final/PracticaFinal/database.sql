-- Table for users
CREATE TABLE Users (
    user_id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255),
    email VARCHAR(255)
);


-- Table for cities
CREATE TABLE City (
    city_id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    city_name VARCHAR(255)
);


-- Table for cinemas
CREATE TABLE Cinema (
    cinema_id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    cinema_name VARCHAR(255),
    city_id INT,
    FOREIGN KEY (city_id) REFERENCES City(city_id)
);

-- Table for movies
CREATE TABLE Film (
    film_id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    cinema_id INT,
    film_name VARCHAR(255),
    synopsis VARCHAR(3000),
    film_page VARCHAR(255),
    original_title VARCHAR(255),
    genre VARCHAR(50),
    nationality VARCHAR(50),
    duration INT,
    release_year INT,
    distributor VARCHAR(255),
    director VARCHAR(255),
    actors VARCHAR(3000),
    classification VARCHAR(10),
    other_data VARCHAR(3000),
    FOREIGN KEY (cinema_id) REFERENCES Cinema(cinema_id)
);

-- Table for theaters
CREATE TABLE Sala (
    sala_id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    cinema_id INT,
    theater_name VARCHAR(255),
    rows_count INT,
    columns_count INT,
    FOREIGN KEY (cinema_id) REFERENCES Cinema(cinema_id)
);


-Tabla para Sesiones
CREATE TABLE Sesiones (
    sesion_id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    cinema_id INT,
    film_id INT,
    sala_id INT,
    fecha DATE,
    hora TIME,
    FOREIGN KEY (cinema_id) REFERENCES Cinema(cinema_id),
    FOREIGN KEY (film_id) REFERENCES Film(film_id),
    FOREIGN KEY (sala_id) REFERENCES Sala(sala_id)   
);


--Nueva tabla para tickets
-- Table for tickets
CREATE TABLE Ticket (
    ticket_id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    sesion_id INT,
    row_num INT,
    column_number INT,
    FOREIGN KEY (sesion_id) REFERENCES Sesiones(sesion_id)
    
);



-- Table for reservations
CREATE TABLE Reservation (
    reservation_id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id INT,
    ticket_id INT,
    FOREIGN KEY (user_id) REFERENCES Users(user_id),
    FOREIGN KEY (ticket_id) REFERENCES Ticket(ticket_id)
);

-- Table for comments
CREATE TABLE Comment (
    comment_id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    comment_text VARCHAR(30000),
    rating INT,
    user_id INT,
    film_id INT,
    FOREIGN KEY (user_id) REFERENCES Users(user_id),
    FOREIGN KEY (film_id) REFERENCES Film(film_id)
);






-- Dodaj prvog korisnika
INSERT INTO Users (first_name, last_name, username, password, email)
VALUES ('Filip', 'Celepirovic', 'filip', 'filip', 'filip@gmail.com');

-- Dodaj drugog korisnika
INSERT INTO Users (first_name, last_name, username, password, email)
VALUES ('admin', 'admin', 'admin', 'admin', 'admin@gmail.com');





-- Ubaci gradove
INSERT INTO City (city_name) VALUES ('Beograd');
INSERT INTO City (city_name) VALUES ('Novi Sad');
-- Dodajte koliko god gradova želite

-- Ubaci bioskope
INSERT INTO Cinema (cinema_name, city_id) VALUES ('Cineplex Beograd', 1);
INSERT INTO Cinema (cinema_name, city_id) VALUES ('Arena Cineplex Novi Sad', 2);
-- Dodajte koliko god bioskopa želite

-- Ubaci filmove
INSERT INTO Film (cinema_id, film_name, synopsis, film_page, original_title, genre, nationality, duration, release_year, distributor, director, actors, classification, other_data) 
VALUES (1, 'Film 1', 'Ovo je sinopsis filma 1', 'link-do-stranice-filma-1', 'Originalni naslov filma 1', 'Akcija', 'Američki', 120, 2022, 'Distributer 1', 'Režiser 1', 'Glumci filma 1', 'PG-13', 'Dodatni podaci o filmu 1');
-- Dodajte koliko god filmova želite

-- Ubaci sale
INSERT INTO Sala (cinema_id, theater_name, rows_count, columns_count) VALUES (1, 'Sala 1', 10, 15);
INSERT INTO Sala (cinema_id, theater_name, rows_count, columns_count) VALUES (2, 'Sala 2', 8, 12);
-- Dodajte koliko god sala želite

-- Ubaci sesije
INSERT INTO Sesiones (cinema_id, film_id, sala_id, fecha, hora) VALUES (1, 1, 1, '2024-01-07', '18:00:00');
INSERT INTO Sesiones (cinema_id, film_id, sala_id, fecha, hora) VALUES (2, 1, 2, '2024-01-08', '20:00:00');
-- Dodajte koliko god sesija želite

-- Ubaci karte
INSERT INTO Ticket (sesion_id, row_num, column_number) VALUES (1, 5, 8);
INSERT INTO Ticket (sesion_id, row_num, column_number) VALUES (2, 3, 6);
-- Dodajte koliko god karata želite

-- Ubaci rezervacije
INSERT INTO Reservation (user_id, ticket_id) VALUES (2, 1);
-- Dodajte koliko god rezervacija želite





-- Insert 50 cities into the City table
INSERT INTO City (city_name) VALUES
('Zagreb'), ('Split'), ('Osijek'), ('Rijeka'), ('Zadar'),
('Belgrade'), ('Novi Sad'), ('Nis'), ('Kragujevac'), ('Subotica'),
('Pula'), ('Dubrovnik'), ('Sibenik'), ('Varazdin'), ('Sisak'),
('Novi Pazar'), ('Kraljevo'), ('Leskovac'), ('Uzice'), ('Cacak'),
('Karlovac'), ('Slavonski Brod'), ('Pancevo'), ('Krusevac'), ('Valjevo'),
('Ruma'), ('Kikinda'), ('Sombor'), ('Vranje'), ('Pirot'),
('Samobor'), ('Bjelovar'), ('Vinkovci'), ('Koprivnica'), ('Djakovo'),
('Smederevo'), ('Sremska Mitrovica'), ('Zrenjanin'), ('Sabac'), ('Subotica'),
('Kula'), ('Loznica'), ('Vrsac'), ('Zajecar'), ('Negotin'),
('Svilajnac'), ('Prokuplje');




-- Insert 50 cinemas into the Cinema table with valid city_id values
INSERT INTO Cinema (cinema_name, city_id) VALUES
('Cinema1', 1), ('Cinema2', 2), ('Cinema3', 3), ('Cinema4', 4), ('Cinema5', 5),
('Cinema6', 6), ('Cinema7', 7), ('Cinema8', 8), ('Cinema9', 9), ('Cinema10', 10),
('Cinema11', 11), ('Cinema12', 12), ('Cinema13', 13), ('Cinema14', 14), ('Cinema15', 15),
('Cinema16', 16), ('Cinema17', 17), ('Cinema18', 18), ('Cinema19', 19), ('Cinema20', 20),
('Cinema21', 21), ('Cinema22', 22), ('Cinema23', 23), ('Cinema24', 24), ('Cinema25', 25),
('Cinema26', 26), ('Cinema27', 27), ('Cinema28', 28), ('Cinema29', 29), ('Cinema30', 30),
('Cinema31', 31), ('Cinema32', 32), ('Cinema33', 33), ('Cinema34', 34), ('Cinema35', 35),
('Cinema36', 36), ('Cinema37', 37), ('Cinema38', 38), ('Cinema39', 39), ('Cinema40', 40),
('Cinema41', 41), ('Cinema42', 42), ('Cinema43', 43), ('Cinema44', 44), ('Cinema45', 45),
('Cinema46', 46), ('Cinema47', 47), ('Cinema48', 48), ('Cinema49', 49);
