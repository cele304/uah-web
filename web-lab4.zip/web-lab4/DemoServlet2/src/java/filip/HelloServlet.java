/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package filip;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

/**
 *
 * @author filip
 */
public class HelloServlet extends HttpServlet {

    String nombre;
public void service( HttpServletRequest peticion, HttpServletResponse
respuesta ) throws ServletException, IOException
{
nombre = peticion.getParameter("NOMBRE");
ServletOutputStream out = respuesta.getOutputStream();
out.println("<html>");
out.println("<head><title>Hola Servlet</title></head>");
out.println("<body>");
out.println("<p><h1><center>Su nombre es: <B>"+nombre+"</B></center></h1></p>");
out.println("</body></html>");
out.close();
}
}
