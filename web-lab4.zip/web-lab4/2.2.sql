- Tabla profesor
CREATE TABLE Profesor (
  DNI varchar(15) NOT NULL,
  Nombre varchar(20) NOT NULL,
  Apellido varchar(30) NOT NULL,
  Sueldo FLOAT NOT NULL,
  PRIMARY KEY (DNI)
);

-- Tabla asignatura
CREATE TABLE Asignatura (
  IdAsignatura varchar(15) NOT NULL,
  Nombre varchar(20) NOT NULL,
  Descripcion varchar(30) NOT NULL,
  DNI_Profesor varchar(15) NOT NULL,
  PRIMARY KEY (IdAsignatura),
  FOREIGN KEY (DNI_Profesor) REFERENCES Profesor(DNI)
);

-- Tabla alumno
CREATE TABLE Alumno (
  DNI varchar(15) NOT NULL,
  Nombre varchar(20) NOT NULL,
  Apellido varchar(30) NOT NULL,
  PRIMARY KEY (DNI)
);

-- Tabla intermedia de relación "alumno asiste a clase"
CREATE TABLE Asiste (
  DNI_Alumno varchar(15) NOT NULL,
  IdAsignatura varchar(15) NOT NULL,
  PRIMARY KEY (DNI_Alumno, IdAsignatura),
  FOREIGN KEY (DNI_Alumno) REFERENCES Alumno(DNI),
  FOREIGN KEY (IdAsignatura) REFERENCES Asignatura(IdAsignatura)
);

-- Dodaj 10 profesora
INSERT INTO Profesor VALUES
('111111111A', 'Roberto', 'Barchino', 2500),
('222222222B', 'Ana', 'Anić', 2600),
('333333333C', 'Marko', 'Markić', 2700),
('444444444D', 'Elena', 'Elenić', 2800),
('555555555E', 'Luka', 'Lukić', 2900),
('666666666F', 'Petra', 'Petrić', 3000),
('777777777G', 'Jure', 'Jurić', 3100),
('888888888H', 'Klara', 'Klarić', 3200),
('999999999I', 'Stipe', 'Stipić', 3300),
('101010101J', 'Marija', 'Marijić', 3400);

-- Dodaj 10 predmeta
INSERT INTO Asignatura VALUES
('ASIG1', 'Matematika', 'Opis matematike', '111111111A'),
('ASIG2', 'Fizika', 'Opis fizike', '222222222B'),
('ASIG3', 'Informatika', 'Opis informatike', '333333333C'),
('ASIG4', 'Biologija', 'Opis biologije', '444444444D'),
('ASIG5', 'Povijest', 'Opis povijesti', '555555555E'),
('ASIG6', 'Engleski jezik', 'Opis engleskog jezika', '666666666F'),
('ASIG7', 'Kemija', 'Opis kemije', '777777777G'),
('ASIG8', 'Likovna umjetnost', 'Opis likovne umjetnosti', '888888888H'),
('ASIG9', 'Tjelesno odgoj', 'Opis tjelesnog odgoja', '999999999I'),
('ASIG10', 'Glazbena umjetnost', 'Opis glazbene umjetnosti', '101010101J');

-- Dodaj 10 studenata
INSERT INTO Alumno VALUES
('111111111X', 'Filip', 'Ćelepirović'),
('222222222Y', 'Iva', 'Ivić'),
('333333333Z', 'Marin', 'Marinić'),
('444444444W', 'Ela', 'Elić'),
('555555555K', 'Leo', 'Leonić'),
('666666666L', 'Petra', 'Petrić'),
('777777777M', 'Jakov', 'Jakovljević'),
('888888888N', 'Mia', 'Mijić'),
('999999999O', 'Stjepan', 'Stjepanić'),
('101010101P', 'Martina', 'Martinović');

-- Dodaj 10 veza između studenata i predmeta
INSERT INTO Asiste VALUES
('111111111X', 'ASIG1'),
('222222222Y', 'ASIG2'),
('333333333Z', 'ASIG3'),
('444444444W', 'ASIG4'),
('555555555K', 'ASIG5'),
('666666666L', 'ASIG6'),
('777777777M', 'ASIG7'),
('888888888N', 'ASIG8'),
('999999999O', 'ASIG9'),
('101010101P', 'ASIG10');
