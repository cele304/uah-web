-- Kreiranje tablice APP.CIRCUITO
CREATE TABLE CIRCUITO (
    NAME VARCHAR(30) not null,
    CITY VARCHAR(30) not null,
    STATE VARCHAR(30) not null,
    VUELTAS INTEGER,
    LONGITUD REAL,
    CURVAS INTEGER
);

-- Kreiranje tablice APP.COCHE
CREATE TABLE COCHE (
    NAME VARCHAR(30) not null,
    GANANCIA REAL
);


-- Unos podataka u tablicu APP.CIRCUITO
INSERT INTO CIRCUITO (NAME, CITY, STATE, VUELTAS, LONGITUD, CURVAS)
VALUES
    ('Circuit de Catalunya', 'Montmelo', 'Španjolska', 66, 4655, 16),
    ('Monza Circuit', 'Monza', 'Italija', 53, 5793, 11),
    ('Silverstone Circuit', 'Silverstone', 'Velika Britanija', 52, 5891, 18),
    ('Circuit de Monaco', 'Monte Carlo', 'Monako', 78, 3337, 19),
    ('Suzuka Circuit', 'Suzuka', 'Japan', 53, 5807, 18);

-- Unos podataka u tablicu APP.COCHE
INSERT INTO COCHE (NAME, GANANCIA)
VALUES
    ('Ferrari SF21', 8),
    ('Mercedes-AMG W12', 9),
    ('Red Bull Racing RB16B', 8.5),
    ('Alpine A521', 7.8),
    ('McLaren MCL35M', 8.2);

